
// =============================================
// DIGITAL RECIPE PLANNER
// COMPLETE FRONTEND JAVASCRIPT
// =============================================

const API = 'http://localhost:3000/api/recipes';
const MEAL_API = 'http://localhost:3000/api/meals';
const PANTRY_API = 'http://localhost:3000/api/pantry';
const SHOPPING_API = 'http://localhost:3000/api/shopping-list';
const INGREDIENT_API = 'http://localhost:3000/api/ingredients';
const CALENDAR_API = 'http://localhost:3000/api/meals/calendar';

let allRecipes = [];
let availableRecipes = [];
let selectedMealIngredients = [];
let editingMealId = null;

// =============================================
// COMMON FUNCTIONS
// =============================================

function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[char]);
}

async function fetchJSON(url, options = {}) {
    const response = await fetch(url, options);
    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.error || 'Request failed');
    }

    return data;
}

// =============================================
// DASHBOARD HEADER
// =============================================

function updateDashboardHeader() {
    const now = new Date();
    const hour = now.getHours();

    let greeting = 'WELCOME, CHEF.';

    if (hour < 12) greeting = 'GOOD MORNING, CHEF.';
    else if (hour < 17) greeting = 'GOOD AFTERNOON, CHEF.';
    else greeting = 'GOOD EVENING, CHEF.';

    document.getElementById('greeting').textContent = greeting;

    document.getElementById('currentDate').textContent =
        now.toLocaleDateString('en-IN', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
}

updateDashboardHeader();

// =============================================
// RECIPE STORE
// =============================================

async function loadRecipes() {
    try {
        allRecipes = await fetchJSON(API);

        displayRecipes(allRecipes);

        document.getElementById('recipeCount').textContent =
            allRecipes.length;

        await loadRecipeOptions();

    } catch (error) {
        document.getElementById('recipeContainer').textContent =
            'Unable to load recipes. Check your backend server.';

        console.error(error);
    }
}

function displayRecipes(recipes) {
    const container = document.getElementById('recipeContainer');

    if (!recipes.length) {
        container.innerHTML =
            '<p>No recipes found. Add your first recipe!</p>';
        return;
    }

    container.innerHTML = recipes.map(recipe => `
        <div class="recipe-card">
            <h3>${escapeHTML(recipe.recipe_name)}</h3>
            <p>${escapeHTML(recipe.description || 'No description')}</p>
            <p>⏱ ${escapeHTML(recipe.cooking_time || 'N/A')} minutes</p>
            <p>Difficulty: ${escapeHTML(recipe.difficulty || 'N/A')}</p>
            <p>${escapeHTML(recipe.instructions || '')}</p>
        </div>
    `).join('');
}

function searchRecipes() {
    const search =
        document.getElementById('searchRecipe').value.toLowerCase();

    const filtered = allRecipes.filter(recipe =>
        recipe.recipe_name.toLowerCase().includes(search)
    );

    displayRecipes(filtered);
}

function openRecipeForm() {
    document.getElementById('recipeForm').style.display = 'block';
    loadRecipeIngredientOptions();
}

function closeRecipeForm() {
    document.getElementById('recipeForm').style.display = 'none';
}

async function loadRecipeIngredientOptions() {
    const select = document.getElementById('recipeIngredients');

    try {
        const ingredients = await fetchJSON(INGREDIENT_API);

        select.innerHTML = '';

        ingredients.forEach(item => {
            const option = document.createElement('option');
            option.value = item.ingredient_id;
            option.textContent = item.ingredient_name;
            select.appendChild(option);
        });

    } catch (error) {
        console.error(error);
        select.innerHTML =
            '<option value="">Unable to load ingredients</option>';
    }
}

async function addRecipe() {
    const recipe = {
        recipe_name:
            document.getElementById('recipeName').value.trim(),

        description:
            document.getElementById('recipeDescription').value.trim(),

        cooking_time:
            document.getElementById('cookingTime').value,

        difficulty:
            document.getElementById('difficulty').value,

        instructions:
            document.getElementById('instructions').value.trim(),

        ingredient_ids: Array.from(
            document.getElementById('recipeIngredients').selectedOptions
        ).map(option => Number(option.value))
    };

    if (!recipe.recipe_name) {
        alert('Please enter a recipe name.');
        return;
    }

    try {
        await fetchJSON(API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(recipe)
        });

        alert('Recipe saved successfully!');

        closeRecipeForm();

        document.getElementById('recipeName').value = '';
        document.getElementById('recipeDescription').value = '';
        document.getElementById('cookingTime').value = '';
        document.getElementById('difficulty').value = '';
        document.getElementById('instructions').value = '';

        await loadRecipes();

    } catch (error) {
        alert(error.message);
    }
}

// =============================================
// MEAL PLANNER
// =============================================

// Load recipe options into meal form
async function loadRecipeOptions() {
    try {
        availableRecipes = await fetchJSON(API);

        const select = document.getElementById('mealRecipe');

        select.innerHTML =
            '<option value="">Choose a recipe</option>';

        availableRecipes.forEach(recipe => {
            select.innerHTML += `
                <option value="${recipe.recipe_id}">
                    ${escapeHTML(recipe.recipe_name)}
                </option>
            `;
        });

    } catch (error) {
        console.error('Could not load recipes:', error);
    }
}

function openMealForm() {
    editingMealId = null;

    document.getElementById('mealForm').style.display = 'block';

    document.querySelector('#mealForm h3').textContent =
        'ADD TO MEAL PLAN';

    loadRecipeOptions();
}

function closeMealForm() {
    document.getElementById('mealForm').style.display = 'none';
    editingMealId = null;
}

function showMealForm(type) {
    openMealForm();
    document.getElementById('mealType').value = type;
}

// Add or update meal
async function addMeal() {
    const recipe_id =
        document.getElementById('mealRecipe').value;

    const meal_date =
        document.getElementById('mealDate').value;

    const meal_type =
        document.getElementById('mealType').value;

    if (!recipe_id || !meal_date || !meal_type) {
        alert('Please complete all meal details.');
        return;
    }

    const payload = { recipe_id, meal_date, meal_type };

    try {
        const url = editingMealId
            ? `${MEAL_API}/${editingMealId}`
            : MEAL_API;

        const method = editingMealId ? 'PUT' : 'POST';

        await fetchJSON(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        alert(editingMealId
            ? 'Meal updated successfully!'
            : 'Meal planned successfully!');

        closeMealForm();

        await refreshMealData();

    } catch (error) {
        alert(error.message);
    }
}

// Load ALL planned meals
async function loadAllMeals() {
    const container = document.getElementById('allPlannedMeals');

    if (!container) return;

    try {
        const meals = await fetchJSON(MEAL_API);

        if (!meals.length) {
            container.innerHTML =
                '<p>No planned meals yet. Add your first meal!</p>';
            return;
        }

        container.innerHTML = meals.map(meal => `
            <div class="meal-card planned-meal-card">
                <span>
                    ${escapeHTML(meal.meal_type.toUpperCase())}
                </span>

                <h3>${escapeHTML(meal.recipe_name)}</h3>

                <p>
                    ${escapeHTML(meal.meal_date)}
                </p>

                <button onclick="editPlannedMeal(${meal.plan_id})">
                    Edit
                </button>

                <button onclick="removeMeal(${meal.plan_id})">
                    Delete
                </button>
            </div>
        `).join('');

    } catch (error) {
        container.innerHTML =
            '<p>Unable to load planned meals.</p>';

        console.error(error);
    }
}

// Edit meal using the existing meal form
async function editPlannedMeal(id) {
    try {
        const meals = await fetchJSON(MEAL_API);

        const meal = meals.find(
            item => Number(item.plan_id) === Number(id)
        );

        if (!meal) {
            alert('Meal not found.');
            return;
        }

        editingMealId = id;

        document.getElementById('mealForm').style.display = 'block';

        document.querySelector('#mealForm h3').textContent =
            'EDIT PLANNED MEAL';

        await loadRecipeOptions();

        document.getElementById('mealRecipe').value =
            meal.recipe_id;

        document.getElementById('mealDate').value =
            String(meal.meal_date).slice(0, 10);

        document.getElementById('mealType').value =
            meal.meal_type;

        document.getElementById('mealForm').scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });

    } catch (error) {
        alert(error.message);
    }
}

// Load today's meal cards
async function loadTodayMeals() {
    try {
        const meals = await fetchJSON(`${MEAL_API}/today`);

        const slots = {
            Breakfast: 'breakfastMeal',
            Lunch: 'lunchMeal',
            Dinner: 'dinnerMeal'
        };

        Object.values(slots).forEach(id => {
            document.getElementById(id).textContent =
                'No meal scheduled';
        });

        meals.forEach(meal => {
            const element =
                document.getElementById(slots[meal.meal_type]);

            if (element) {
                element.innerHTML = `
                    ${escapeHTML(meal.recipe_name)}
                    <button onclick="editPlannedMeal(${meal.plan_id})">
                        Edit
                    </button>
                    <button onclick="removeMeal(${meal.plan_id})">
                        Delete
                    </button>
                `;
            }
        });

    } catch (error) {
        console.error(error);
    }
}

async function loadMealCount() {
    try {
        const data = await fetchJSON(`${MEAL_API}/count`);

        document.getElementById('mealCount').textContent =
            data.total;

    } catch (error) {
        console.error(error);
    }
}

// Delete meal
async function removeMeal(id) {
    if (!confirm('Remove this planned meal?')) return;

    try {
        await fetchJSON(`${MEAL_API}/${id}`, {
            method: 'DELETE'
        });

        await refreshMealData();

        alert('Meal removed successfully!');

    } catch (error) {
        alert(error.message);
    }
}

// Refresh all meal-related data
async function refreshMealData() {
    await Promise.all([
        loadTodayMeals(),
        loadMealCount(),
        loadAllMeals(),
        loadPlannedMealOptions(),
        loadCalendar()
    ]);
}

// Default meal date
document.getElementById('mealDate').value =
    new Date().toLocaleDateString('en-CA');

// =============================================
// CALENDAR VIEW
// =============================================

let calendarDate = new Date();

async function loadCalendar() {
    const container = document.getElementById('calendarDays');

    if (!container) return;

    try {
        const meals = await fetchJSON(CALENDAR_API);

        const year = calendarDate.getFullYear();
        const month = calendarDate.getMonth();

        document.getElementById('calendarMonth').textContent =
            calendarDate.toLocaleDateString('en-IN', {
                month: 'long',
                year: 'numeric'
            });

        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);

        let startDay = (firstDay.getDay() + 6) % 7;

        let html = '';

        for (let i = 0; i < startDay; i++) {
            html += '<div class="calendar-day empty"></div>';
        }

        for (let day = 1; day <= lastDay.getDate(); day++) {
            const date =
                `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

            const dayMeals = meals.filter(meal =>
                String(meal.meal_date).slice(0, 10) === date
            );

            html += `
                <div class="calendar-day">
                    <strong>${day}</strong>

                    ${dayMeals.map(meal => `
                        <div class="calendar-meal">
                            ${escapeHTML(meal.meal_type)}:
                            ${escapeHTML(meal.recipe_name)}
                        </div>
                    `).join('')}
                </div>
            `;
        }

        container.innerHTML = html;

    } catch (error) {
        container.innerHTML =
            '<p>Could not load calendar.</p>';

        console.error(error);
    }
}

function changeCalendarMonth(direction) {
    calendarDate.setMonth(calendarDate.getMonth() + direction);
    loadCalendar();
}

// =============================================
// SIDEBAR NAVIGATION
// =============================================

const mainContent = document.querySelector('.main-content');
const navigationLinks =
    document.querySelectorAll('#sidebarNav a');

const pageSections =
    document.querySelectorAll('.dashboard-section');

function showPage(pageName) {
    mainContent.dataset.page = pageName;

    pageSections.forEach(section => {
        section.classList.remove('active');
    });

    const selectedSection =
        document.getElementById(pageName);

    if (selectedSection && pageName !== 'dashboard') {
        selectedSection.classList.add('active');
    }

    navigationLinks.forEach(link => {
        link.classList.toggle(
            'active',
            link.dataset.page === pageName
        );
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (pageName === 'shoppingList') {
        loadPlannedMealOptions();
        loadShoppingList();
    }

    if (pageName === 'mealPlanner') {
        loadAllMeals();
    }

    if (pageName === 'calendarView') {
        loadCalendar();
    }
}

navigationLinks.forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault();

        const pageName = this.dataset.page;

        showPage(pageName);

        history.replaceState(null, '', `#${pageName}`);
    });
});

const validPages = [
    'dashboard',
    'recipeStore',
    'mealPlanner',
    'shoppingList',
    'smartPantry',
    'calendarView'
];

const initialPage = location.hash.substring(1);

showPage(
    validPages.includes(initialPage)
        ? initialPage
        : 'dashboard'
);

// =============================================
// SMART PANTRY
// =============================================

async function loadIngredientOptions() {
    const dropdown =
        document.getElementById('pantryIngredient');

    try {
        const ingredients = await fetchJSON(INGREDIENT_API);

        dropdown.innerHTML =
            '<option value="">Select an ingredient</option>';

        ingredients.forEach(item => {
            const option = document.createElement('option');

            option.value = item.ingredient_name;
            option.textContent = item.ingredient_name;

            dropdown.appendChild(option);
        });

    } catch (error) {
        dropdown.innerHTML =
            '<option value="">Unable to load ingredients</option>';

        console.error(error);
    }
}

async function loadPantry() {
    try {
        const ingredients = await fetchJSON(PANTRY_API);

        displayPantry(ingredients);

        document.getElementById('pantryCount').textContent =
            ingredients.length;

        await loadPantryRecommendations();

    } catch (error) {
        document.getElementById('pantryList').textContent =
            'Unable to load pantry ingredients.';

        console.error(error);
    }
}

function displayPantry(ingredients) {
    const container = document.getElementById('pantryList');

    document.getElementById('pantryTotal').textContent =
        `${ingredients.length} ITEMS`;

    if (!ingredients.length) {
        container.innerHTML =
            '<p>Your pantry is empty. Add your first ingredient!</p>';
        return;
    }

    container.innerHTML = ingredients.map(item => `
        <div class="pantry-item">
            <div>
                <h4>${escapeHTML(item.ingredient_name)}</h4>
                <p>Quantity: ${escapeHTML(item.quantity || 'Not specified')}</p>
            </div>

            <div class="pantry-actions">
                <button onclick="editPantryIngredient(
                    ${item.pantry_id},
                    '${escapeHTML(item.quantity || '')}'
                )">
                    Edit
                </button>

                <button class="delete-pantry"
                    onclick="deletePantryIngredient(${item.pantry_id})">
                    Remove
                </button>
            </div>
        </div>
    `).join('');
}

async function addPantryIngredient() {
    const ingredient_name =
        document.getElementById('pantryIngredient').value;

    const quantity =
        document.getElementById('pantryQuantity').value.trim();

    if (!ingredient_name) {
        alert('Please select an ingredient.');
        return;
    }

    try {
        const result = await fetchJSON(PANTRY_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ingredient_name,
                quantity,
                expiry_date: null
            })
        });

        document.getElementById('pantryIngredient').value = '';
        document.getElementById('pantryQuantity').value = '';

        document.getElementById('pantryMessage').textContent =
            result.message || 'Ingredient added successfully!';

        await loadPantry();

    } catch (error) {
        alert(error.message);
    }
}

async function editPantryIngredient(id, oldQuantity) {
    const quantity = prompt(
        'Enter updated quantity:',
        oldQuantity
    );

    if (quantity === null) return;

    try {
        await fetchJSON(`${PANTRY_API}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                quantity,
                expiry_date: null
            })
        });

        await loadPantry();

    } catch (error) {
        alert(error.message);
    }
}

async function deletePantryIngredient(id) {
    if (!confirm('Remove this ingredient from your pantry?')) return;

    try {
        await fetchJSON(`${PANTRY_API}/${id}`, {
            method: 'DELETE'
        });

        await loadPantry();

    } catch (error) {
        alert(error.message);
    }
}

async function loadPantryRecommendations() {
    const container =
        document.getElementById('pantryRecommendations');

    try {
        const recipes = await fetchJSON(
            `${PANTRY_API}/recommendations`
        );

        if (!recipes.length) {
            container.innerHTML =
                '<p>No recipe ingredient data available yet.</p>';
            return;
        }

        container.innerHTML = recipes.map(recipe => `
            <div class="pantry-item">
                <div>
                    <h4>${escapeHTML(recipe.recipe_name)}</h4>

                    <p>Match: ${recipe.match_percentage}%</p>

                    <p>
                        Ingredients available:
                        ${recipe.matched_ingredients}/${recipe.total_ingredients}
                    </p>

                    <p>
                        Missing:
                        ${escapeHTML(recipe.missing_ingredients || 'None')}
                    </p>
                </div>
            </div>
        `).join('');

    } catch (error) {
        container.innerHTML =
            '<p>Unable to load recipe recommendations.</p>';

        console.error(error);
    }
}

// =============================================
// SHOPPING LIST
// =============================================

// Load every planned meal into dropdown
async function loadPlannedMealOptions() {
    const select =
        document.getElementById('plannedMealSelect');

    if (!select) return;

    try {
        const meals = await fetchJSON(MEAL_API);

        select.innerHTML =
            '<option value="">Choose a planned meal</option>';

        meals.forEach(meal => {
            const option = document.createElement('option');

            option.value = meal.plan_id;

            option.textContent =
                `${meal.recipe_name} - ${meal.meal_type} (${meal.meal_date})`;

            select.appendChild(option);
        });

        if (!meals.length) {
            select.innerHTML =
                '<option value="">No planned meals available</option>';
        }

    } catch (error) {
        select.innerHTML =
            '<option value="">Unable to load meals</option>';

        console.error(error);
    }
}

// Load ingredients for selected meal
async function loadMealIngredients() {
    const mealId =
        document.getElementById('plannedMealSelect').value;

    const container =
        document.getElementById('mealIngredients');

    selectedMealIngredients = [];

    if (!mealId) {
        container.innerHTML =
            '<p>Select a meal to view its ingredients.</p>';
        return;
    }

    try {
        const ingredients = await fetchJSON(
            `${MEAL_API}/${mealId}/ingredients`
        );

        selectedMealIngredients = ingredients;

        if (!ingredients.length) {
            container.innerHTML =
                '<p>No ingredients linked to this recipe.</p>';
            return;
        }

        container.innerHTML = `
            <h3>RECIPE INGREDIENTS</h3>

            ${ingredients.map((item, index) => `
                <div class="shopping-item">
                    <label>
                        <input
                            type="checkbox"
                            class="meal-ingredient"
                            data-index="${index}"
                            checked
                        >

                        <span>
                            ${escapeHTML(item.ingredient_name)}
                        </span>
                    </label>

                    <span class="shopping-quantity">
                        ${escapeHTML(item.quantity || 'As needed')}
                    </span>
                </div>
            `).join('')}
        `;

    } catch (error) {
        container.innerHTML =
            '<p>Unable to load recipe ingredients.</p>';

        console.error(error);
    }
}

// Add selected ingredients to shopping list
async function addSelectedToShoppingList() {
    const checkboxes = [
        ...document.querySelectorAll('.meal-ingredient:checked')
    ];

    if (!checkboxes.length) {
        alert('Please select at least one ingredient.');
        return;
    }

    try {
        for (const checkbox of checkboxes) {
            const item =
                selectedMealIngredients[
                    Number(checkbox.dataset.index)
                ];

            await fetchJSON(SHOPPING_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ingredient_name: item.ingredient_name,
                    quantity: item.quantity || 'As needed'
                })
            });
        }

        alert('Selected ingredients added successfully!');

        await loadShoppingList();

    } catch (error) {
        alert(error.message);
    }
}

// Load shopping list

async function loadShoppingList() {
    const container = document.getElementById('shoppingItems');
    if (!container) return;

    try {
        const items = await fetchJSON(SHOPPING_API);

        const purchased = items.filter(
            item => Number(item.is_purchased) === 1
        ).length;

        const countElement = document.getElementById('shoppingCount');
        if (countElement) countElement.textContent = items.length;

        document.getElementById('shoppingProgress').textContent =
            `${purchased} of ${items.length} items purchased`;

        const doneContainer = document.getElementById('shoppingDoneContainer');

        if (doneContainer) {
            doneContainer.style.display =
                items.length > 0 && purchased === items.length
                    ? 'block'
                    : 'none';
        }

        if (!items.length) {
            container.innerHTML =
                '<p>Your shopping list is empty.</p>';
            return;
        }

        container.innerHTML = items.map(item => `
            <div class="shopping-item">
                <label class="${
                    Number(item.is_purchased) === 1 ? 'purchased' : ''
                }">
                    <input
                        type="checkbox"
                        ${Number(item.is_purchased) === 1 ? 'checked' : ''}
                        onchange="toggleShoppingItem(
                            ${item.list_id},
                            this.checked
                        )"
                    >
                    <span>${escapeHTML(item.ingredient_name)}</span>
                </label>

                <span class="shopping-quantity">
                    ${escapeHTML(item.quantity || '')}
                </span>

                <button onclick="removeShoppingItem(${item.list_id})">
                    Remove
                </button>
            </div>
        `).join('');

    } catch (error) {
        container.innerHTML =
            '<p>Could not load shopping list.</p>';
        console.error(error);
    }
}

// Clear all purchased items after completing the shopping trip
async function completeShoppingList() {
    try {
        const items = await fetchJSON(SHOPPING_API);

        const purchasedItems = items.filter(
            item => Number(item.is_purchased) === 1
        );

        if (purchasedItems.length === 0) return;

        for (const item of purchasedItems) {
            await fetchJSON(`${SHOPPING_API}/${item.list_id}`, {
                method: 'DELETE'
            });
        }

        await loadShoppingList();

    } catch (error) {
        alert(error.message);
    }
}


// Mark ingredient as purchased
async function toggleShoppingItem(id, checked) {
    try {
        await fetchJSON(`${SHOPPING_API}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                is_purchased: checked
            })
        });

        await loadShoppingList();

    } catch (error) {
        alert(error.message);
    }
}

// Remove shopping item
async function removeShoppingItem(id) {

    try {
        await fetchJSON(`${SHOPPING_API}/${id}`, {
            method: 'DELETE'
        });

        await loadShoppingList();

    } catch (error) {
        alert(error.message);
    }
}

// =============================================
// INITIAL LOAD
// =============================================

loadRecipes();
loadRecipeOptions();

loadTodayMeals();
loadMealCount();
loadAllMeals();

loadIngredientOptions();
loadPantry();

loadCalendar();

loadPlannedMealOptions();
loadShoppingList();
