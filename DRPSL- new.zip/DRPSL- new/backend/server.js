
const express = require('express');
const db = require('./db');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// =====================================
// TEST DATABASE CONNECTION
// =====================================

app.get('/api/test', (req, res) => {
    db.query('SHOW TABLES', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});

// =====================================
// RECIPE STORE
// =====================================

// Get all recipes
app.get('/api/recipes', (req, res) => {
    const sql = `
        SELECT * FROM recipes
        ORDER BY LOWER(recipe_name) ASC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});
app.get('/api/meals/:id/ingredients', (req, res) => {
    const sql = `
        SELECT
            i.ingredient_id,
            i.ingredient_name,
            ri.quantity
        FROM meal_plans mp
        JOIN recipe_ingredients ri
            ON mp.recipe_id = ri.recipe_id
        JOIN ingredients i
            ON ri.ingredient_id = i.ingredient_id
        WHERE mp.plan_id = ?
        AND mp.user_id = 1
        ORDER BY i.ingredient_name
    `;

    db.query(sql, [req.params.id], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});
// Add a recipe
// Add recipe with its ingredients
app.post('/api/recipes', (req, res) => {
    const {
        recipe_name,
        description,
        cooking_time,
        difficulty,
        instructions,
        ingredient_ids
    } = req.body;

    if (!recipe_name || !recipe_name.trim()) {
        return res.status(400).json({ error: 'Recipe name is required.' });
    }

    const sql = `
        INSERT INTO recipes
        (recipe_name, description, cooking_time, difficulty, instructions)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.query(sql, [
        recipe_name.trim(),
        description || null,
        cooking_time || null,
        difficulty || null,
        instructions || null
    ], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const recipeId = result.insertId;
        const ids = [...new Set(
            Array.isArray(ingredient_ids)
                ? ingredient_ids.map(Number).filter(Number.isInteger)
                : []
        )];

        if (ids.length === 0) {
            return res.status(201).json({
                message: 'Recipe added successfully!',
                recipe_id: recipeId
            });
        }

        const values = ids.map(id => [recipeId, id, null]);

        db.query(
            `INSERT INTO recipe_ingredients
             (recipe_id, ingredient_id, quantity)
             VALUES ?`,
            [values],
            (ingredientErr) => {
                if (ingredientErr) {
                    return res.status(500).json({
                        error: ingredientErr.message,
                        recipe_id: recipeId
                    });
                }

                res.status(201).json({
                    message: 'Recipe and ingredients saved successfully!',
                    recipe_id: recipeId
                });
            }
        );
    });
});


// =====================================
// MEAL PLANNER API
// =====================================

// Get ALL planned meals (all dates)
app.get('/api/meals', (req, res) => {
    const sql = `
        SELECT
            mp.plan_id,
            DATE_FORMAT(mp.meal_date, '%Y-%m-%d') AS meal_date,
            mp.meal_type,
            r.recipe_id,
            r.recipe_name
        FROM meal_plans mp
        JOIN recipes r ON mp.recipe_id = r.recipe_id
        WHERE mp.user_id = 1
        ORDER BY mp.meal_date ASC,
        FIELD(mp.meal_type, 'Breakfast', 'Lunch', 'Dinner')
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Get today's meals
app.get('/api/meals/today', (req, res) => {
    const sql = `
        SELECT
            mp.plan_id,
            DATE_FORMAT(mp.meal_date, '%Y-%m-%d') AS meal_date,
            mp.meal_type,
            r.recipe_id,
            r.recipe_name
        FROM meal_plans mp
        JOIN recipes r ON mp.recipe_id = r.recipe_id
        WHERE mp.meal_date = CURDATE()
        AND mp.user_id = 1
        ORDER BY FIELD(mp.meal_type, 'Breakfast', 'Lunch', 'Dinner')
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Add a planned meal
app.post('/api/meals', (req, res) => {
    const { recipe_id, meal_date, meal_type } = req.body;

    if (!recipe_id || !meal_date || !meal_type) {
        return res.status(400).json({
            error: 'Recipe, date and meal type are required.'
        });
    }

    if (!['Breakfast', 'Lunch', 'Dinner'].includes(meal_type)) {
        return res.status(400).json({ error: 'Invalid meal type.' });
    }

    const sql = `
        INSERT INTO meal_plans
        (user_id, recipe_id, meal_date, meal_type)
        VALUES (1, ?, ?, ?)
    `;

    db.query(sql, [recipe_id, meal_date, meal_type], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });

        res.status(201).json({
            message: 'Meal planned successfully!',
            plan_id: result.insertId
        });
    });
});

// Edit an existing planned meal
app.put('/api/meals/:id', (req, res) => {
    const { recipe_id, meal_date, meal_type } = req.body;

    if (!recipe_id || !meal_date || !meal_type) {
        return res.status(400).json({
            error: 'Recipe, date and meal type are required.'
        });
    }

    if (!['Breakfast', 'Lunch', 'Dinner'].includes(meal_type)) {
        return res.status(400).json({ error: 'Invalid meal type.' });
    }

    const sql = `
        UPDATE meal_plans
        SET recipe_id = ?, meal_date = ?, meal_type = ?
        WHERE plan_id = ? AND user_id = 1
    `;

    db.query(sql, [
        recipe_id,
        meal_date,
        meal_type,
        req.params.id
    ], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Meal not found.' });
        }

        res.json({ message: 'Meal updated successfully!' });
    });
});

// Get ingredients belonging to a planned meal
app.get('/api/meals/:id/ingredients', (req, res) => {
    const sql = `
        SELECT
            i.ingredient_id,
            i.ingredient_name,
            ri.quantity
        FROM meal_plans mp
        JOIN recipe_ingredients ri ON mp.recipe_id = ri.recipe_id
        JOIN ingredients i ON ri.ingredient_id = i.ingredient_id
        WHERE mp.plan_id = ? AND mp.user_id = 1
        ORDER BY i.ingredient_name ASC
    `;

    db.query(sql, [req.params.id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Get total planned meals
app.get('/api/meals/count', (req, res) => {
    db.query(
        'SELECT COUNT(*) AS total FROM meal_plans WHERE user_id = 1',
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results[0]);
        }
    );
});

// Delete a planned meal
app.delete('/api/meals/:id', (req, res) => {
    const sql = `
        DELETE FROM meal_plans
        WHERE plan_id = ? AND user_id = 1
    `;

    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Meal not found.' });
        }

        res.json({ message: 'Meal removed successfully!' });
    });
});

// =====================================
// CALENDAR VIEW
// =====================================

// Get ALL planned meals for the calendar
app.get('/api/meals/calendar', (req, res) => {
    const sql = `
        SELECT
            mp.plan_id,
            DATE_FORMAT(mp.meal_date, '%Y-%m-%d') AS meal_date,
            mp.meal_type,
            r.recipe_id,
            r.recipe_name
        FROM meal_plans mp
        JOIN recipes r ON mp.recipe_id = r.recipe_id
        WHERE mp.user_id = 1
        ORDER BY
            mp.meal_date ASC,
            FIELD(
                mp.meal_type,
                'Breakfast', 'Lunch', 'Dinner'
            )
    `;

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});

// =====================================
// SMART PANTRY
// =====================================

// Get all pantry ingredients
app.get('/api/pantry', (req, res) => {
    const sql = `
        SELECT
            pantry_id,
            ingredient_name,
            quantity,
            expiry_date
        FROM pantry
        WHERE user_id = 1
        ORDER BY ingredient_name ASC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});

// Add or update pantry ingredient
app.post('/api/pantry', (req, res) => {
    const { ingredient_name, quantity, expiry_date } = req.body;

    if (!ingredient_name || !ingredient_name.trim()) {
        return res.status(400).json({
            error: 'Ingredient name is required.'
        });
    }

    const name = ingredient_name.trim();
    const qty = quantity ? String(quantity).trim() : null;
    const expiry = expiry_date || null;

    const checkSql = `
        SELECT pantry_id
        FROM pantry
        WHERE user_id = 1
        AND LOWER(TRIM(ingredient_name)) = LOWER(?)
    `;

    db.query(checkSql, [name], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (results.length > 0) {
            const updateSql = `
                UPDATE pantry
                SET quantity = ?, expiry_date = ?
                WHERE pantry_id = ? AND user_id = 1
            `;

            db.query(updateSql, [
                qty,
                expiry,
                results[0].pantry_id
            ], (updateErr) => {
                if (updateErr) {
                    return res.status(500).json({
                        error: updateErr.message
                    });
                }

                res.json({
                    message: 'Pantry ingredient updated successfully!'
                });
            });

        } else {
            const insertSql = `
                INSERT INTO pantry
                (user_id, ingredient_name, quantity, expiry_date)
                VALUES (1, ?, ?, ?)
            `;

            db.query(insertSql, [name, qty, expiry], (insertErr, result) => {
                if (insertErr) {
                    return res.status(500).json({
                        error: insertErr.message
                    });
                }

                res.status(201).json({
                    message: 'Ingredient added successfully!',
                    pantry_id: result.insertId
                });
            });
        }
    });
});

// Update pantry ingredient
app.put('/api/pantry/:id', (req, res) => {
    const { quantity, expiry_date } = req.body;

    const sql = `
        UPDATE pantry
        SET quantity = ?, expiry_date = ?
        WHERE pantry_id = ? AND user_id = 1
    `;

    db.query(sql, [
        quantity || null,
        expiry_date || null,
        req.params.id
    ], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                error: 'Pantry ingredient not found.'
            });
        }

        res.json({
            message: 'Pantry ingredient updated successfully!'
        });
    });
});

// Delete pantry ingredient
app.delete('/api/pantry/:id', (req, res) => {
    const sql = `
        DELETE FROM pantry
        WHERE pantry_id = ? AND user_id = 1
    `;

    db.query(sql, [req.params.id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                error: 'Pantry ingredient not found.'
            });
        }

        res.json({
            message: 'Ingredient removed successfully!'
        });
    });
});

// Get pantry ingredient count
app.get('/api/pantry/count', (req, res) => {
    const sql = `
        SELECT COUNT(*) AS total
        FROM pantry
        WHERE user_id = 1
    `;

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results[0]);
    });
});

// =====================================
// START SERVER
// =====================================
// GET ALL INGREDIENTS IN ALPHABETICAL ORDER
app.get('/api/ingredients', (req, res) => {
    const sql = `
        SELECT ingredient_id, ingredient_name
        FROM ingredients
        ORDER BY LOWER(ingredient_name) ASC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});
// GET INGREDIENTS IN ALPHABETICAL ORDER
app.get('/api/ingredients', (req, res) => {
    const sql = `
        SELECT ingredient_id, ingredient_name
        FROM ingredients
        ORDER BY LOWER(ingredient_name) ASC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            console.error('Ingredient Error:', err);
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});
// SMART PANTRY RECIPE RECOMMENDATIONS

app.get('/api/pantry/recommendations', (req, res) => {
    const sql = `
        SELECT
            r.recipe_id,
            r.recipe_name,
            r.description,
            r.cooking_time,
            r.difficulty,

            COUNT(DISTINCT i.ingredient_id) AS total_ingredients,

            COUNT(DISTINCT CASE
                WHEN p.pantry_id IS NOT NULL THEN i.ingredient_id
            END) AS matched_ingredients,

            ROUND(
                COUNT(DISTINCT CASE
                    WHEN p.pantry_id IS NOT NULL THEN i.ingredient_id
                END) * 100.0 /
                COUNT(DISTINCT i.ingredient_id)
            ) AS match_percentage,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN p.pantry_id IS NULL THEN i.ingredient_name
                END
                ORDER BY i.ingredient_name
                SEPARATOR ', '
            ) AS missing_ingredients

        FROM recipes r
        JOIN recipe_ingredients ri
            ON r.recipe_id = ri.recipe_id
        JOIN ingredients i
            ON ri.ingredient_id = i.ingredient_id
        LEFT JOIN pantry p
            ON LOWER(TRIM(p.ingredient_name)) =
               LOWER(TRIM(i.ingredient_name))
            AND p.user_id = 1

        GROUP BY r.recipe_id
        ORDER BY match_percentage DESC, LOWER(r.recipe_name) ASC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            console.error('Recommendation error:', err);
            return res.status(500).json({
                error: 'Unable to generate recommendations'
            });
        }

        res.json(results);
    });
});



app.get('/api/pantry/recommendations', (req, res) => {
    const sql = `
        SELECT
            r.recipe_id,
            r.recipe_name,
            r.description,
            r.cooking_time,
            r.difficulty,
            COUNT(DISTINCT i.ingredient_id) AS total_ingredients,
            COUNT(DISTINCT CASE
                WHEN p.pantry_id IS NOT NULL THEN i.ingredient_id
            END) AS matched_ingredients,
            ROUND(
                COUNT(DISTINCT CASE
                    WHEN p.pantry_id IS NOT NULL THEN i.ingredient_id
                END) * 100.0 /
                NULLIF(COUNT(DISTINCT i.ingredient_id), 0)
            ) AS match_percentage,
            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN p.pantry_id IS NULL THEN i.ingredient_name
                END
                ORDER BY i.ingredient_name
                SEPARATOR ', '
            ) AS missing_ingredients
        FROM recipes r
        JOIN recipe_ingredients ri
            ON r.recipe_id = ri.recipe_id
        JOIN ingredients i
            ON ri.ingredient_id = i.ingredient_id
        LEFT JOIN pantry p
            ON LOWER(TRIM(p.ingredient_name)) =
               LOWER(TRIM(i.ingredient_name))
            AND p.user_id = 1
        GROUP BY r.recipe_id
        ORDER BY match_percentage DESC;
    `;

    db.query(sql, (err, results) => {
        if (err) {
            console.error('Recommendation error:', err);
            return res.status(500).json({
                error: 'Unable to generate recommendations'
            });
        }

        res.json(results);
    });
});

// GET: Display shopping list
app.get('/api/shopping-list', (req, res) => {
    const sql = `
        SELECT * FROM shopping_lists
        WHERE user_id = 1
        ORDER BY list_id DESC
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// POST: Add shopping item
app.post('/api/shopping-list', (req, res) => {
    const { ingredient_name, quantity } = req.body;

    if (!ingredient_name || !ingredient_name.trim()) {
        return res.status(400).json({ error: 'Ingredient name required' });
    }

    const sql = `
        INSERT INTO shopping_lists
        (user_id, ingredient_name, quantity, is_purchased)
        VALUES (1, ?, ?, 0)
    `;

    db.query(sql, [ingredient_name.trim(), quantity || null], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Item added successfully', list_id: result.insertId });
    });
});

// PUT: Mark item as purchased or unpurchased
app.put('/api/shopping-list/:id', (req, res) => {
    const { is_purchased } = req.body;

    db.query(
        'UPDATE shopping_lists SET is_purchased = ? WHERE list_id = ? AND user_id = 1',
        [is_purchased ? 1 : 0, req.params.id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Shopping item updated' });
        }
    );
});

// DELETE: Remove shopping item
app.delete('/api/shopping-list/:id', (req, res) => {
    db.query(
        'DELETE FROM shopping_lists WHERE list_id = ? AND user_id = 1',
        [req.params.id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Shopping item removed' });
        }
    );
});

// =====================================
// MEAL-BASED SHOPPING LIST
// =====================================

// Get all planned meals for selection
app.get('/api/shopping-list/meals', (req, res) => {
    const sql = `
        SELECT
            mp.plan_id,
            mp.recipe_id,
            DATE_FORMAT(mp.meal_date, '%Y-%m-%d') AS meal_date,
            mp.meal_type,
            r.recipe_name
        FROM meal_plans mp
        JOIN recipes r ON mp.recipe_id = r.recipe_id
        WHERE mp.user_id = 1
        ORDER BY mp.meal_date ASC,
                 FIELD(mp.meal_type, 'Breakfast', 'Lunch', 'Dinner')
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Get ingredients for one selected planned meal
app.get('/api/shopping-list/meals/:planId/ingredients', (req, res) => {
    const sql = `
        SELECT
            i.ingredient_id,
            i.ingredient_name,
            ri.quantity
        FROM meal_plans mp
        JOIN recipe_ingredients ri
            ON mp.recipe_id = ri.recipe_id
        JOIN ingredients i
            ON ri.ingredient_id = i.ingredient_id
        WHERE mp.plan_id = ?
          AND mp.user_id = 1
        ORDER BY i.ingredient_name ASC
    `;

    db.query(sql, [req.params.planId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});

// Generate shopping list from selected meals
app.post('/api/shopping-list/generate', (req, res) => {
    const planIds = [...new Set(
        (Array.isArray(req.body.plan_ids) ? req.body.plan_ids : [])
            .map(Number)
            .filter(id => Number.isInteger(id) && id > 0)
    )];

    if (planIds.length === 0) {
        return res.status(400).json({ error: 'Select at least one meal.' });
    }

    const placeholders = planIds.map(() => '?').join(',');

    const ingredientSql = `
        SELECT
            i.ingredient_name,
            GROUP_CONCAT(
                DISTINCT NULLIF(TRIM(ri.quantity), '')
                ORDER BY ri.quantity SEPARATOR ' + '
            ) AS quantity
        FROM meal_plans mp
        JOIN recipe_ingredients ri ON mp.recipe_id = ri.recipe_id
        JOIN ingredients i ON ri.ingredient_id = i.ingredient_id
        WHERE mp.user_id = 1
          AND mp.plan_id IN (${placeholders})
        GROUP BY i.ingredient_id, i.ingredient_name
        ORDER BY i.ingredient_name ASC
    `;

    db.query(ingredientSql, planIds, (err, ingredients) => {
        if (err) return res.status(500).json({ error: err.message });

        if (ingredients.length === 0) {
            return res.status(400).json({
                error: 'The selected meals have no saved ingredients.'
            });
        }

        // Replace the previous shopping list with this selection
        db.query(
            'DELETE FROM shopping_lists WHERE user_id = 1',
            (deleteErr) => {
                if (deleteErr) {
                    return res.status(500).json({ error: deleteErr.message });
                }

                const values = ingredients.map(item => [
                    1,
                    item.ingredient_name,
                    item.quantity,
                    0
                ]);

                db.query(
                    `INSERT INTO shopping_lists
                     (user_id, ingredient_name, quantity, is_purchased)
                     VALUES ?`,
                    [values],
                    (insertErr) => {
                        if (insertErr) {
                            return res.status(500).json({
                                error: insertErr.message
                            });
                        }

                        res.json({
                            message: 'Shopping list generated successfully!',
                            total_items: ingredients.length
                        });
                    }
                );
            }
        );
    });
});

// Get generated shopping list
app.get('/api/shopping-list', (req, res) => {
    db.query(
        `SELECT * FROM shopping_lists
         WHERE user_id = 1
         ORDER BY ingredient_name ASC`,
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        }
    );
});

// Mark ingredient purchased or unpurchased
app.put('/api/shopping-list/:id', (req, res) => {
    db.query(
        `UPDATE shopping_lists
         SET is_purchased = ?
         WHERE list_id = ? AND user_id = 1`,
        [req.body.is_purchased ? 1 : 0, req.params.id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Shopping item updated.' });
        }
    );
});

// Remove ingredient
app.delete('/api/shopping-list/:id', (req, res) => {
    db.query(
        `DELETE FROM shopping_lists
         WHERE list_id = ? AND user_id = 1`,
        [req.params.id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Shopping item removed.' });
        }
    );
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
